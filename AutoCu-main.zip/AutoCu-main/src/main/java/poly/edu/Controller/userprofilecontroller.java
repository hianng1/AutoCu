package poly.edu.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class userprofilecontroller {

    @GetMapping("/user1")
    public String showUser1(Model model) {
        // Bạn có thể thêm dữ liệu vào model ở đây nếu cần
        // Ví dụ: model.addAttribute("message", "Hello from Controller!");

        return "user1"; // Tên của file JSP (user1.jsp)
    }
}
