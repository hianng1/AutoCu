package poly.edu.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import poly.edu.Model.HinhAnhSanPham;

public interface HinhAnhSanPhamRepository extends JpaRepository<HinhAnhSanPham, Long> {
}
