package poly.edu.Repository;

public interface ChitietgiohangRepository {

}
